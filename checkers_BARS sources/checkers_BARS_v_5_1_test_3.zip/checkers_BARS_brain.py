'''
this program writing Bakay Egor, Moscow, Russia, 2020
BARS_brain version: 1.0
download: https://yadi.sk/d/QsL3RJtT-QnlLA
tutorial: https://www.youtube.com/playlist?list=PL24VxeCr7LD1Z3Cm_VS4bLKthcGdkNWSD
rate app: https://docs.google.com/forms/d/e/1FAIpQLSfOLysTI8F9iPvoiu5R__bpcbtZvHo4up4pca1XKYu9sgEkxA/viewform

# 9  - нельзя занимать - белая
# 0  - свободная черная клетка
# 1  - белая шашка
# 11 - белая дамка
# 2  - черная шашка
# 12 - черная дамка

area_monitor = [[9, 2, 9, 2, 9, 2, 9, 2],
                [2, 9, 2, 9, 2, 9, 2, 9],
                [9, 2, 9, 2, 9, 2, 9, 2],
                [0, 9, 0, 9, 0, 9, 0, 9],
                [9, 0, 9, 0, 9, 0, 9, 0],
                [1, 9, 1, 9, 1, 9, 1, 9],
                [9, 1, 9, 1, 9, 1, 9, 1],
                [1, 9, 1, 9, 1, 9, 1, 9]]
'''

from random import * # x0 = randint(0, 100)
from copy import deepcopy 
import time
from time import sleep
from time import time
Time = int(time()*1000)

def BARS_mind(area_monitor, go_color, level_hard):
    
    def map(x, in_min, in_max, out_min, out_max):
        return int((x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min);
    
    def millis():
        return int(time()*1000);

    def cut(i, a):
        if (abs(i) > a):
            i = abs(i)/i*a;
            i = int(i);
        return i;
    
    def znak(a):
        if   (a > 0):
            return  1
        elif (a < 0):
            return -1
        else:
            return  0

    def more_color(go_color):
        if (go_color==1):
            return 2
        elif (go_color==2):
            return 1
        else:
            return 0

    def print_mas(mas):
        i = 0
        while (i<len(mas)):
            print(mas[i])
            i = i + 1
    
    def generator_move(area_operation, go_color):
        area = deepcopy(area_operation)
        klik = [[-1,-1],
                [-1,-1]]
        go_operation = []
        count1 = 0
        
        def bumerang(go_operation, count1, y2, x2):

            def znak2(r):
                if (r>0):
                    return 1
                else:
                    return 0
                
            if (len(go_operation[len(go_operation)-1])<2):
                return 1
            else:
                into = go_operation[len(go_operation)-1][len(go_operation[len(go_operation)-1])-1]  # самый последний элемент
                into = into%100
                y1 = int(into/10)
                x1 = into%10
                into = go_operation[len(go_operation)-1][len(go_operation[len(go_operation)-1])-2] # самый предпоследний элемент
                into = into%100
                y0 = int(into/10)
                x0 = into%10
                a = znak2(x1-x0)
                b = znak2(y1-y0)
                c = znak2(x2-x1)
                d = znak2(y2-y1)
                if ((a==0 and c==1 or a==1 and c==0) and (d==0 and b==1 or d==1 and b==0)): # просто алгебра логики
                    return 0 # <=====
                    #return 1
                else:
                    return 1
    
        def eating2(go_operation, count1, area1, y0, x0, y1, x1):
            klik = [[x0,y0],
                    [x1,y1]]
            if(1):
                if(1):
                    if(1):
                        area2 = deepcopy(area1)
                        q = area2[ klik[0][1] ][ klik[0][0] ]
                        area2[ klik[0][1] ][ klik[0][0] ] = 0
                        area2[ klik[1][1] ][ klik[1][0] ] = q
                        x0c = klik[0][0]
                        y0c = klik[0][1]
                        x1c = klik[1][0]
                        y1c = klik[1][1]
                        c = 0
                        if ((abs(x0c-x1c)==abs(y0c-y1c) and abs(y0c-y1c)>=2)): # eat
                            while (x1c!=x0c):
                                if (area2[y0c][x0c] != 0):
                                    if(1): # записать в go_operation какие шашки были съедены
                                        count1 = count1 + 1
                                        into = go_operation[len(go_operation)-1][len(go_operation[len(go_operation)-1])-1]
                                        go_operation[len(go_operation)-1][len(go_operation[len(go_operation)-1])-1] = 10000+area2[y0c][x0c]*100+y0c*10+x0c
                                        go_operation[len(go_operation)-1].append(into)
                                        #go_operation[len(go_operation)-1].append(10000+area2[y0c][x0c]*100+y0c*10+x0c)
                                    area2[y0c][x0c] = area2[y0c][x0c] + 100 # правило одной руки
                                    #area2[y0c][x0c] = 0
                                x0c = x0c + znak(x1c-x0c)
                                y0c = y0c + znak(y1c-y0c)
                        area2[ klik[0][1] ][ klik[0][0] ] = 0
                        eating(go_operation, count1, area2, go_color, y1, x1)
        
        def eating(go_operation, count1, area_operation, go_color, y, x):
            #global count1
            #global go_operation
            count1 = count1 + 1
            area = deepcopy(area_operation)
            x0 = klik[0][0]
            y0 = klik[0][1]
            x1 = klik[1][0]
            y1 = klik[1][1]
            eat = 0
            xa = 0 # shaska => damka
            while (xa <= 7):
                if (area[0][xa] == 1):
                    area[0][xa] = area[0][xa] + 10
                if (area[7][xa] == 2):
                    area[7][xa] = area[7][xa] + 10
                xa = xa + 1
            if(1):
                if (area[y][x]==go_color): # proverka na vozmognost siest shaskami
                    if (y-2>=0 and x-2>=0):
                        if (area[y][x]%10!=area[y-1][x-1]%10 and area[y-1][x-1]<100 and area[y][x]!=0 and area[y-1][x-1]!=0 and area[y-2][x-2]==0 and bumerang(go_operation, count1, y-2, x-2)):
                            eat = 1
                            a = 0
                            if (y==2 and go_color==1):
                                a = 1000 
                            go_operation[len(go_operation)-1].append(a+go_color*100+(y-2)*10+(x-2))
                            eating2(go_operation, count1, area, y, x, y-2, x-2)
                    if (y+2<=7 and x-2>=0):
                        if (area[y][x]%10!=area[y+1][x-1]%10 and area[y+1][x-1]<100 and area[y][x]!=0 and area[y+1][x-1]!=0 and area[y+2][x-2]==0 and bumerang(go_operation, count1, y+2, x-2)):
                            eat = 1
                            a = 0
                            if (y==5 and go_color==2):
                                a = 1000 
                            go_operation[len(go_operation)-1].append(a+go_color*100+(y+2)*10+(x-2))
                            eating2(go_operation, count1, area, y, x, y+2, x-2)
                    if (y-2>=0 and x+2<=7):
                        if (area[y][x]%10!=area[y-1][x+1]%10 and area[y-1][x+1]<100 and area[y][x]!=0 and area[y-1][x+1]!=0 and area[y-2][x+2]==0 and bumerang(go_operation, count1, y-2, x+2)):
                            eat = 1
                            a = 0
                            if (y==2 and go_color==1):
                                a = 1000 
                            go_operation[len(go_operation)-1].append(a+go_color*100+(y-2)*10+(x+2))
                            eating2(go_operation, count1, area, y, x, y-2, x+2)
                    if (y+2<=7 and x+2<=7):
                        if (area[y][x]%10!=area[y+1][x+1]%10 and area[y+1][x+1]<100 and area[y][x]!=0 and area[y+1][x+1]!=0 and area[y+2][x+2]==0 and bumerang(go_operation, count1, y+2, x+2)): 
                            eat = 1
                            a = 0
                            if (y==5 and go_color==2):
                                a = 1000 
                            go_operation[len(go_operation)-1].append(a+go_color*100+(y+2)*10+(x+2))
                            eating2(go_operation, count1, area, y, x, y+2, x+2)
                if (area[y][x]==go_color+10 and 1): # proverka na vozmognost siest damkami 
                    xd1 = x
                    xd2 = x
                    xd3 = x
                    xd4 = x
                    yd1 = y
                    yd2 = y
                    yd3 = y
                    yd4 = y
                    i = 0
                    while (i < 10):
                        if (yd1>0 and xd1>0 and area[yd1-1][xd1-1]==0 and area[yd1-1][xd1-1]<100):
                            yd1 = yd1 - 1
                            xd1 = xd1 - 1
                        if (yd2<7 and xd2>0 and area[yd2+1][xd2-1]==0 and area[yd2+1][xd2-1]<100):
                            yd2 = yd2 + 1
                            xd2 = xd2 - 1
                        if (yd3>0 and xd3<7 and area[yd3-1][xd3+1]==0 and area[yd3-1][xd3+1]<100):
                            yd3 = yd3 - 1
                            xd3 = xd3 + 1
                        if (yd4<7 and xd4<7 and area[yd4+1][xd4+1]==0 and area[yd4+1][xd4+1]<100):
                            yd4 = yd4 + 1
                            xd4 = xd4 + 1
                        i = i + 1
                    if (yd1-2>=0 and xd1-2>=0):
                        if (go_color!=area[yd1-1][xd1-1]%10 and area[yd1-1][xd1-1]<100 and area[yd1-1][xd1-1]!=0 and area[yd1-2][xd1-2]==0 and bumerang(go_operation, count1, yd1-1, xd1-1)):
                            eat = 1
                            yd1 = yd1 - 2
                            xd1 = xd1 - 2
                            if (1):
                                i = 1
                                while (yd1>=0 and xd1>=0 and i==1):
                                    go_operation[len(go_operation)-1].append(1000+go_color*100+(yd1)*10+(xd1))
                                    eating2(go_operation, count1, area, y, x, yd1, xd1)
                                    #if (area[yd1][xd1]==0 and yd1==y1 and xd1==x1):
                                    yd1 = yd1 - 1
                                    xd1 = xd1 - 1
                                    if (yd1>=0 and xd1>=0 and area[yd1][xd1]!=0):
                                        i = 0
                    if (yd2+2<=7 and xd2-2>=0):
                        if (go_color!=area[yd2+1][xd2-1]%10 and area[yd2+1][xd2-1]<100 and area[yd2+1][xd2-1]!=0 and area[yd2+2][xd2-2]==0 and bumerang(go_operation, count1, yd2+1, xd2-1)):
                            eat = 1
                            yd2 = yd2 + 2
                            xd2 = xd2 - 2
                            if (1):
                                i = 1
                                while (yd2<=7 and xd2>=0 and i==1):
                                    go_operation[len(go_operation)-1].append(1000+go_color*100+(yd2)*10+(xd2))
                                    eating2(go_operation, count1, area, y, x, yd2, xd2)
                                    #if (area[yd2][xd2]==0 and yd2==y1 and xd2==x1):
                                    yd2 = yd2 + 1
                                    xd2 = xd2 - 1
                                    if (yd2<=7 and xd2>=0 and area[yd2][xd2]!=0):
                                        i = 0
                    if (yd3-2>=0 and xd3+2<=7):
                        if (go_color!=area[yd3-1][xd3+1]%10 and area[yd3-1][xd3+1]<100 and area[yd3-1][xd3+1]!=0 and area[yd3-2][xd3+2]==0 and bumerang(go_operation, count1, yd3-1, xd3+1)):
                            eat = 1
                            yd3 = yd3 - 2
                            xd3 = xd3 + 2
                            if (1):
                                i = 1
                                while (yd3>=0 and xd3<=7 and i==1):
                                    go_operation[len(go_operation)-1].append(1000+go_color*100+(yd3)*10+(xd3))
                                    eating2(go_operation, count1, area, y, x, yd3, xd3)
                                    #if (area[yd3][xd3]==0 and yd3==y1 and xd3==x1):
                                    yd3 = yd3 - 1
                                    xd3 = xd3 + 1
                                    if (yd3>=0 and xd3<=7 and area[yd3][xd3]!=0):
                                        i = 0
                    if (yd4+2<=7 and xd4+2<=7):
                        if (go_color!=area[yd4+1][xd4+1]%10 and area[yd4+1][xd4+1]<100 and area[yd4+1][xd4+1]!=0 and area[yd4+2][xd4+2]==0 and bumerang(go_operation, count1, yd4+1, xd4+1)):
                            eat = 1
                            yd4 = yd4 + 2
                            xd4 = xd4 + 2
                            if (1):
                                i = 1
                                while (yd4<=7 and xd4<=7 and i==1):
                                    go_operation[len(go_operation)-1].append(1000+go_color*100+(yd4)*10+(xd4))
                                    eating2(go_operation, count1, area, y, x, yd4, xd4)
                                    #if (area[yd4][xd4]==0 and yd4==y1 and xd4==x1):
                                    yd4 = yd4 + 1
                                    xd4 = xd4 + 1
                                    if (yd4<=7 and xd4<=7 and area[yd4][xd4]!=0):
                                        i = 0
                    #==================================================================
            count1 = count1 - 1
            if (eat==0 and len(go_operation[len(go_operation) - 1])>1):
                #print(count1)
                go_operation.append([])
                i = 0
                c = len(go_operation) - 1
                while (i < count1):
                    go_operation[c].append(go_operation[c-1][i])
                    i = i + 1
            else:
                del go_operation[len(go_operation) - 1][count1]
            if (len(go_operation[len(go_operation)-1])>0):
                if (go_operation[len(go_operation)-1][len(go_operation[len(go_operation)-1])-1]>2000):
                    del go_operation[len(go_operation)-1][len(go_operation[len(go_operation)-1])-1]
                    count1 = count1 - 1
            return eat
        ##############################################################################
        x = 0
        y = 0
        eat = 0
        while (y<=7):
            go_operation.append([area[y][x]*100+y*10+x])
            if (eating(go_operation, count1, area, go_color, y ,x)==1):
                eat = 1
            else:
                del go_operation[len(go_operation)-1]
            x = x + 1
            if (x > 7):
                x = 0
                y = y + 1
        if (eat==1):
            wer = 0
            while (len(go_operation) > wer):
                if (len(go_operation[wer])==0):
                    del go_operation[wer]
                else:
                    wer = wer + 1
        #eat = 0
        ###########################
        if (eat==0): # not eat
            go_operation.clear()
            x = 0
            y = 0
            while (y<=7):
                if (area[y][x]%10==go_color):
                    if (area[y][x]/10<1): # not queen
                        if (go_color==1 and y>=1 and x>=1):
                            if (area[y-1][x-1]==0):
                                if (y==1):
                                    go_operation.append([100+y*10+x,1100+(y-1)*10+x-1])
                                else:
                                    go_operation.append([100+y*10+x, 100+(y-1)*10+x-1])
                        if (go_color==1 and y>=1 and x<=6):
                            if (area[y-1][x+1]==0):
                                if (y==1):
                                    go_operation.append([100+y*10+x,1100+(y-1)*10+x+1])
                                else:
                                    go_operation.append([100+y*10+x, 100+(y-1)*10+x+1])
                        if (go_color==2 and y<=6 and x>=1):
                            if (area[y+1][x-1]==0):
                                if (y==6):
                                    go_operation.append([200+y*10+x,1200+(y+1)*10+x-1])
                                else:
                                    go_operation.append([200+y*10+x, 200+(y+1)*10+x-1])
                        if (go_color==2 and y<=6 and x<=6):
                            if (area[y+1][x+1]==0):
                                if (y==6):
                                    go_operation.append([200+y*10+x,1200+(y+1)*10+x+1])
                                else:
                                    go_operation.append([200+y*10+x, 200+(y+1)*10+x+1])
                    else: # queen
                        xd1 = x
                        xd2 = x
                        xd3 = x
                        xd4 = x
                        yd1 = y
                        yd2 = y
                        yd3 = y
                        yd4 = y
                        i = 0
                        while (i < 10):
                            if (yd1>0 and xd1>0 and area[yd1-1][xd1-1]==0):
                                yd1 = yd1 - 1
                                xd1 = xd1 - 1
                                go_operation.append([1000+go_color*100+y*10+x,1000+go_color*100+yd1*10+xd1])
                            if (yd2<7 and xd2>0 and area[yd2+1][xd2-1]==0):
                                yd2 = yd2 + 1
                                xd2 = xd2 - 1
                                go_operation.append([1000+go_color*100+y*10+x,1000+go_color*100+yd2*10+xd2])
                            if (yd3>0 and xd3<7 and area[yd3-1][xd3+1]==0):
                                yd3 = yd3 - 1
                                xd3 = xd3 + 1
                                go_operation.append([1000+go_color*100+y*10+x,1000+go_color*100+yd3*10+xd3])
                            if (yd4<7 and xd4<7 and area[yd4+1][xd4+1]==0):
                                yd4 = yd4 + 1
                                xd4 = xd4 + 1
                                go_operation.append([1000+go_color*100+y*10+x,1000+go_color*100+yd4*10+xd4])
                            i = i + 1
                x = x + 1
                if (x > 7):
                    x = 0
                    y = y + 1
        klik = [[-1,-1],
                [-1,-1]]
        if (1):
            #print('Text text', end='')
            go_operation2 = deepcopy(go_operation)
            i = 0
            if (eat==1 and 0):
                go_operation.clear()
                while (i < len(go_operation2)): # and 0
                    if (len(go_operation2[i]) > 1):
                        go_operation.append(go_operation2[i])
                    i = i + 1
                i = 0
        #=======================================================
        # съесть 0 или 1, 2 или 3?
        if (len(go_operation)>1): # если есть варианты, из чего выбирать
            if (len(go_operation[0])>2): # полюбас надо есть
                i = 0
                while (len(go_operation)>i+1):
                    u = 1
                    if (go_operation[i][0]==go_operation[i+1][0]):
                        flag = 1
                        while (len(go_operation[i])>u+1 and len(go_operation[i+1])>u+1 and flag==1):
                            if (go_operation[i][u]==go_operation[i+1][u] and go_operation[i][u+1]!=go_operation[i+1][u+1]):
                                flag = 0
                            else:
                                u = u + 2
                        if (flag==1):
                            u = u - 2
                        if (go_operation[i][u]==go_operation[i+1][u] and go_operation[i][u+1]!=go_operation[i+1][u+1]):
                            d1 = len(go_operation[i])
                            d2 = len(go_operation[i+1])
                            if (d1==d2):
                                i = i + 1
                            elif (u+2>=d1 and u+2<d2):
                                del go_operation[i]
                            elif (u+2<d1 and u+2>=d2):
                                del go_operation[i+1]
                            else:
                                #print("selection error")
                                #print(i)
                                #print_mas(area)
                                #print_mas(go_operation)
                                i = i + 1
                        else:
                            i = i + 1
                    else:
                        i = i + 1
        #print_go_operation()
        return go_operation
        
    #===================================================================================================================================================================================================
    #===================================================================================================================================================================================================
    #===================================================================================================================================================================================================
        
    def nostardamus_first_mod(area_monitor, go_color):
        go = []

        def evklid(area, go_color, go_color1): # go_operation1 - возможные ходы первого ходящего
            #go_operation_save = generator_move(area,more_color(go_color))
            #go_operation = generator_move(area,go_color)
            if (1): # len(go_operation)>0 and len(go_operation_save)>0 
                x = 0
                y = 0
                e = 0
                z = 1
                i1 = 0
                i2 = 0
                if (go_color==2):
                    z = -1
                while (y<=7):
                    ko = 1.2 # коэффицент - на сколько хорошо, что шашака близка к концу поля (становлению дамкой)
                    if (area[y][x]%10==go_color):
                        i1 = 1
                    if (area[y][x]%10!=go_color):
                        i2 = 1
                    if (area[y][x]==1):
                        e = e + 200*z
                        e = e + int((7-y)*(7-y)*(7-y)*z*ko)
                    if (area[y][x]==11):
                        e = e + 500*z
                    if (area[y][x]==2):
                        e = e - 200*z
                        e = e - int(y*y*y*z*ko)
                    if (area[y][x]==12):
                        e = e - 500*z
                    if (area[y][x]==11 and (x==7 and y==0 or x==6 and y==1 or x==5 and y==2 or x==4 and y==3 or x==3 and y==4 or x==2 and y==5 or x==1 and y==6 or x==0 and y==7)):
                        e = e + 10*z
                    if (area[y][x]==12 and (x==7 and y==0 or x==6 and y==1 or x==5 and y==2 or x==4 and y==3 or x==3 and y==4 or x==2 and y==5 or x==1 and y==6 or x==0 and y==7)):
                        e = e - 10*z
                    if (x<7):
                        x = x + 1
                    else:
                        x = 0
                        y = y + 1          
                #e = e + len(go_operation)*5
                if (i2==0):
                    e = 1000000
                if (i1==0):
                    e = -1000000
            elif (go_color1==1):
                e = -1000000
            else:
                e = 1000000
            if (go_color1==2):
                go_operation = deepcopy(go_operation_save)
            return e

        def print_coo(yy,xx):
            if  (xx==0):
                print("a", end='')
            elif(xx==1):
                print("b", end='')
            elif(xx==2):
                print("c", end='')
            elif(xx==3):
                print("d", end='')
            elif(xx==4):
                print("e", end='')
            elif(xx==5):
                print("f", end='')
            elif(xx==6):
                print("g", end='')
            elif(xx==7):
                print("h", end='')
            else:
                print("error")
            print(-yy+8, end='')

        def going(area1, moving1):
            area = deepcopy(area1)
            moving = deepcopy(moving1)
            i = 0
            while (len(moving)>i+1):
                x0 = moving[i]%10
                y0 = int(moving[i]/10)%10
                i = i + 1
                if (moving[i]>5000):
                    i = i + 1
                x1 = moving[i]%10
                y1 = int(moving[i]/10)%10
                c = int(moving[i]/100)
                while (x1!=x0):
                    area[y0][x0] = 0
                    x0 = x0 + znak(x1-x0)
                    y0 = y0 + znak(y1-y0)
                area[y1][x1] = c
            return area
        
        def helper(go, area1,H,go_color,go_color1):
            area = deepcopy(area1)
            #if (go_color1==2):
            go_operation = generator_move(area,more_color(go_color))
            go_operation_save = deepcopy(go_operation)
            if (len(go_operation)==0): # если в прошлый ход был заперт соперник
                if (H%2==1):
                    go[len(go)-1][len(go[len(go)-1])-1] = 1000000
                else:
                    go[len(go)-1][len(go[len(go)-1])-1] = -1000000
            else:
                e = len(go_operation)*5
                if (len(go_operation[0])>=3): # надо есть
                    e *= 10
                if (0):
                    if (H%2==1):
                        go[len(go)-1][len(go[len(go)-1])-1] -= e
                    else:
                        go[len(go)-1][len(go[len(go)-1])-1] += e
                i = 0
                while (len(go_operation_save)>i): #  and i<1
                    area2 = going(area, go_operation_save[i])
                    go[len(go)-1].append(go_operation_save[i])
                    go[len(go)-1].append(evklid(area2, go_color, more_color(go_color1)))
                    mas = deepcopy(go[len(go)-1])
                    if (int(len(go[len(go)-1])/2)<H and abs(go[len(go)-1][len(go[len(go)-1])-1])<999999):
                        helper(go, area2,H,more_color(go_color))
                    go.append(deepcopy(mas))
                    #if (abs(go[len(go)-1][len(go[len(go)-1])-1])<999999 or 1): # or 1
                    del go[len(go)-1][len(go[len(go)-1])-1]
                    del go[len(go)-1][len(go[len(go)-1])-1]
                    i = i + 1
                if (abs(go[len(go)-1][len(go[len(go)-1])-1])<999999 and 1):
                    del go[len(go)-1]
            
            
            
        go.clear()
        H = 2
        go.append(evklid(area_monitor, go_color, 1)) # оценка в начале позиции 
        #generator_move(area_operation,go_color) # сделано в evklid
        go_operation = generator_move(area_monitor,go_color)
        go_operation_save = deepcopy(go_operation)
        i = 0
        timer = millis()
        while (i<len(go_operation_save)): # записываем возможные ходы в данный момент времени, и каждый раз вызываем рекрусивно просчет helper
            area_monitor1 = going(area_monitor, go_operation_save[i])
            go.append([go_operation_save[i],evklid(area_monitor1, go_color, 2)])
            helper(go, area_monitor1,H,go_color,2)
            i = i + 1
        timer1 = millis()
        #print("--------")
        #print_mas(go)
        #print ("count:",len(go)-1)
        #print ("time:",(timer1-timer)/1000)
        #print("---------------------")
        # выбор наилучшего хода
        i = 1
        ii = -1000001
        while (i<len(go)):
            if (go[i][len(go[i])-1]>ii):
                ii = go[i][len(go[i])-1]
            i = i + 1
        #print(ii)
        i = 1
        while (i<len(go)):
            if (go[i][len(go[i])-1]<ii):
                del go[i]
            else:
                i = i + 1
        #print_mas(go)
        #print ("count:",len(go)-1)
        i = randint(1, len(go)-1)
        #print("variant: ", i)
        #print("---------------------")
        go_operation = deepcopy(go[i][0])
        return go_operation

    def nostardamus_ultra(area_monitor, go_color):
        go = []
        go_operation = []
        #global area_monitor

        def print_coo(yy,xx):
            if  (xx==0):
                print("a", end='')
            elif(xx==1):
                print("b", end='')
            elif(xx==2):
                print("c", end='')
            elif(xx==3):
                print("d", end='')
            elif(xx==4):
                print("e", end='')
            elif(xx==5):
                print("f", end='')
            elif(xx==6):
                print("g", end='')
            elif(xx==7):
                print("h", end='')
            else:
                print("error")
            print(-yy+8, end='')

        def going(area1, moving1):
            area = deepcopy(area1)
            moving = deepcopy(moving1)
            i = 0
            while (len(moving)>i+1):
                x0 = moving[i]%10
                y0 = int(moving[i]/10)%10
                i = i + 1
                if (moving[i]>5000):
                    i = i + 1
                x1 = moving[i]%10
                y1 = int(moving[i]/10)%10
                c = int(moving[i]/100)
                while (x1!=x0):
                    area[y0][x0] = 0
                    x0 = x0 + znak(x1-x0)
                    y0 = y0 + znak(y1-y0)
                area[y1][x1] = c
            return area
        
        def helper(go, go_operation, area1,go_color,H):
            #global go
            #global go_operation
                        
            area = deepcopy(area1)
            go_operation = generator_move(area,go_color)
            go_operation_save = deepcopy(go_operation)
            i = 0
            #print(go[len(go)-1][len(go[len(go)-1])-1])
            # добавить проверку на дальнейшее поедание фигур
            if (len(go_operation)==0): # если в прошлый ход был заперт соперник
                if (H%2==1):
                    go[len(go)-1][len(go[len(go)-1])-1] = 1000000
                else:
                    go[len(go)-1][len(go[len(go)-1])-1] = -1000000
            else:
                e = len(go_operation)*5
                if (len(go_operation[0])>=3): # надо есть
                    e *= 10
                if (0):
                    if (H%2==1):
                        go[len(go)-1][len(go[len(go)-1])-1] -= e
                    else:
                        go[len(go)-1][len(go[len(go)-1])-1] += e
                    
                #if (len(go_operation_save)>0):
                while (len(go_operation_save)>i): #  and i<1
                    go.append(deepcopy(go[len(go)-1]))
                    area2 = going(area, go_operation_save[i])
                    go[len(go)-2].append(go_operation_save[i])
                    go[len(go)-2].append(evklid_lite(go, go_operation, area2))
                    #if (go[len(go)-2][len(go[len(go)-2])-1]==500):
                    #    print_mas(area2)
                    #    print(evklid_lite(area2))
                    #if (i>0 and 0):
                    #    helper1()
                    i += 1
                del go[len(go)-1]
            #else:
            #    if (H%2==1):
            #        go[len(go)-1][len(go[len(go)-1])-1] = 1000000
            #    else:
            #        go[len(go)-1][len(go[len(go)-1])-1] = -1000000
                #print(go[len(go)-1][len(go[len(go)-1])-1])

        def evklid_lite(go, go_operation, area): # , go_color
            if (1): 
                x = 0
                y = 0
                e = 0
                z = 1
                i1 = 0
                i2 = 0
                if (go_color==2):
                    z = -1
                while (y<=7):
                    ko = 1.3 # коэффицент - на сколько хорошо, что шашака близка к концу поля (становлению дамкой)
                    if (area[y][x]%10==go_color):
                        i1 = 1
                    if (area[y][x]%10==more_color(go_color)):
                        i2 = 1
                    if (area[y][x]==1):
                        e = e + 200*z
                        e = e + int((7-y)*(7-y)*(7-y)*z*ko)
                    if (area[y][x]==11):
                        e = e + 500*z
                    if (area[y][x]==2):
                        e = e - 200*z
                        e = e - int(y*y*y*z*ko)
                    if (area[y][x]==12):
                        e = e - 500*z
                    if (area[y][x]==11 and (x==7 and y==0 or x==6 and y==1 or x==5 and y==2 or x==4 and y==3 or x==3 and y==4 or x==2 and y==5 or x==1 and y==6 or x==0 and y==7)):
                        e = e + 10*z
                    if (area[y][x]==12 and (x==7 and y==0 or x==6 and y==1 or x==5 and y==2 or x==4 and y==3 or x==3 and y==4 or x==2 and y==5 or x==1 and y==6 or x==0 and y==7)):
                        e = e - 10*z
                    if (x<7):
                        x = x + 1
                    else:
                        x = 0
                        y = y + 1
                #e = e + len(go_operation)*5
                if (i2==0):
                    e = 1000000
                if (i1==0):
                    e = -1000000
            else:
                e = -1000000
            return e

        def pifagor(go, go_operation, i,h):
            return i

        def gauss(go, mas):
            #return 0
            #print("!")
            
            def gauss_delete(go, array):
                i = 1
                while (len(go)>i and len(array)>0):
                    if (go[i]==array):
                        del go[i]
                        array.clear()
                    i += 1
                if (len(array)>0):
                    print("error")
            
            def gauss_helper(go, mas):
                # проверка на существование "хорошей" комбинации
                flag = 0
                i = 0
                while (len(mas)>i and flag==0):
                    if (mas[i][len(mas[i])-2]>=go[0]):
                        flag = 1
                    i += 1
                if (flag==0):
                    while (len(mas)>0):
                        #gauss_delete(mas[0])
                        #print(mas[len(mas)-1], mas [len(mas)-1][len(mas[len(mas)-1])-1])
                        #print(go[   mas [len(mas)-1][len(mas[len(mas)-1])-1]   ])
                        del go[   mas [len(mas)-1][len(mas[len(mas)-1])-1]   ]
                        del mas[len(mas)-1]
                    #print()
                    return 0
                else:
                    return 1
                
            # проверка на существование "хорошей" комбинации
            if (gauss_helper(go, mas) and len(mas[0])>3 and 1): #  and len(mas)>0
                # удаляем мой ход из массива
                i = 0
                #print_mas(mas)
                #print(mas[0][0], end='')
                while (len(mas)>i and 1):
                    del mas[i][0]
                    del mas[i][0]
                    i += 1
                #print_mas(mas)
                #print()
                '''
                u = 0
                while (len(mas)>u and 0):
                    i = 0
                    mas2 = []
                    mas2.append(deepcopy(mas[u]))
                    #mas2[0].append(u)
                    #mas = deepcopy(go)
                    while (len(mas)>i):
                        if (mas[u][0]==mas[i][0] and i!=u):
                            mas2.append(deepcopy(mas[i]))
                            #mas2[len(mas2)-1].append(i)
                            #del mas2[len(mas2)-1][0]
                            #del mas2[len(mas2)-1][0]
                        i += 1
                    print_mas(mas2)
                    print()
                    if (gauss_helper(go, mas2)): # т.е. если да, то у противника нет возможности "нагадить" нам в следующем ходе
                        print("!")
                    else:
                        while (len(mas)>0 and 0):
                            #gauss_delete(mas[0])
                            del go[ mas[len(mas)-1][len(mas[len(mas)-1])-1] ]
                            del mas[len(mas)-1]
                    u += 1
                    #print("@")
                    #print_mas(mas)
                    #print("@")
                #else:
                #    while (len(mas)>0):
                #        del mas[len(mas)-1]
                '''
                # выбираем наиболее благоприятную для соперника ситуацию (оставляем варианты с максимальной выгодой для противника)
                u = 0
                min = 9999999
                while (len(mas)>u and 1): 
                    if (mas[u][1]<min):
                        min = mas[u][1]
                    u += 1
                u = len(mas)-1
                while (0<=u and 1): 
                    if (mas[u][1]>min):
                        del go[   mas [u][len(mas[u])-1]   ]
                        del mas[u]
                    u -= 1
                '''
                # выбираем наиболее благоприятную для соперника ситуацию (оставляем варианты, где нет вариантов того, что противник может "не попасться" под удар)
                u = 0
                flag = 1 # нет возможности у противника ответить так, чтобы я в конце не мог его съесть
                while (len(mas)>u and 1): 
                    if (len(mas[u][2])<3):
                        min = mas[u][1]
                    u += 1
                u = len(mas)-1
                while (0<=u and 1): 
                    if (mas[u][1]>min):
                        del go[   mas [u][len(mas[u])-1]   ]
                        del mas[u]
                    u -= 1
                '''
                if (len(mas)>0 and 0):
                    #gauss(go, go_operation, mas)
                    # берем один наш ход, смотрим, как на это может ответить соперник, если все хорошо, то "допускаем" и так в цикле по всему ходу
                    flag = 1
                    u = 0
                    while (len(mas)>u and flag==1):
                        i = 0
                        mas2 = []
                        mas2.append(deepcopy(mas[u]))
                        while (len(mas)>i):
                            if (mas[u][0]==mas[i][0] and i!=u): #  and len(mas[i])>7
                                mas2.append(deepcopy(mas[i]))
                                del mas2[len(mas2)-1][0]
                                del mas2[len(mas2)-1][0]
                            i += 1
                        #if (gauss(go, deepcopy(mas2))==1): # если удалили строку в go
                        #    flag = 0
                        u += 1
                            
                        #print("@")
                        #print_mas(mas)
                        #print("@")
                    if (flag==0):
                        while (len(mas)>0):
                            del go[   mas [len(mas)-1][len(mas[len(mas)-1])-1]   ]
                            del mas[len(mas)-1]
                            return 1
                
            else:
                while (len(mas)>0): # на всякий пожарный
                    del go[   mas [len(mas)-1][len(mas[len(mas)-1])-1]   ]
                    del mas[len(mas)-1]
                return 1 # возвращаем для того, чтобы не переходить к следующим вероятностям, т.к. следующая вероятность стала текущей, из-за удаления в массиве go
                        
        go.clear()
        go_end = []
        go_save = []
        H = 1
        go_operation = generator_move(area_monitor,go_color)
        go_operation_save = deepcopy(go_operation)
        go.append(evklid_lite(go, go_operation, area_monitor)) # оценка в начале позиции
        i = 0
        timer = millis()
        while (i<len(go_operation_save) and len(go_operation_save)>1 and 1): # записываем возможные ходы в данный момент времени, и каждый раз вызываем рекрусивно просчет helper
            area_monitor1 = going(area_monitor, go_operation_save[i])
            go.append([go_operation_save[i],evklid_lite(go, go_operation, area_monitor1)])
            i = i + 1
        if (len(go_operation_save)==1): # один вариант хода
            #area_monitor1 = going(area_monitor, go_operation_save[i])
            #go.append([go_operation_save[i],evklid_lite(area_monitor1)]) #
            print("один вариант")
            go_operation = go_operation_save[0]
            print("===>",go_operation)
        elif(1):
            time_for_mozg = 15000
            go_end.append(deepcopy(go[0]))
            # коэфицент очень сильно меняется ~= 3.4
            while ((millis()-timer)*4<time_for_mozg and H<50): # 
                go_save = deepcopy(go)
                go.clear()
                go.append(go_save[0])
                i = 1
                while (millis()-timer<time_for_mozg+5000 and i<len(go_save)):
                    go.append(go_save[i])
                    if (abs(go[len(go)-1][len(go[len(go)-1])-1])<999999): # если не конец игры
                        area_monitor1 = going(area_monitor, go[len(go)-1][0]) # делаем ходы из истории
                        u = 2
                        while (millis()-timer<time_for_mozg+5000 and u<len(go[len(go)-1])):
                            area_monitor1 = going(area_monitor1, go[len(go)-1][u])
                            u += 2
                        if (H%2==1): # придумываем новые ходы
                            helper(go, go_operation, area_monitor1,more_color(go_color),H)
                        else:
                            helper(go, go_operation, area_monitor1,go_color,H)
                        #print_mas(area_monitor1)
                        #print()
                        #i += 1
                    else:
                        go_end.append(deepcopy(go_save[i]))
                        #del go_save[i]
                        del go[len(go)-1]
                    i += 1
                if (millis()-timer<time_for_mozg+5000 and H>=1 and 1): # хватило времени ####################################################################
                    i = 1
                    go_save = deepcopy(go)
                    
                    while (i<len(go)):
                        u = 2
                        flag = 1
                        while (u<len(go[i]) and flag==1):
                            if (len(go[i][u])==2):
                                flag = 0
                            else:
                                u += 4
                        if (flag==1):
                            i += 1
                        else:
                            go_end.append(deepcopy(go[i])) # записываем удаляемый ход (без полуходов, где не ели)
                            if (1):
                                del go_end[len(go_end)-1][len(go_end[len(go_end)-1])-1]
                                del go_end[len(go_end)-1][len(go_end[len(go_end)-1])-1]
                                #del go_end[len(go_end)-1][len(go_end[len(go_end)-1])-1]
                                #del go_end[len(go_end)-1][len(go_end[len(go_end)-1])-1]
                            if (go_end[len(go_end)-1]==go_end[len(go_end)-2] or len(go_end[len(go_end)-1])==2):
                                del go_end[len(go_end)-1]
                            del go[i]
                            
                    while (len(go)>i and 0):
                        if (len(go[i])>=H*2): # удаляем ходы, в которых никто, в течении 2-х полуходов, не ел
                            if (len(go[i][H*2-2])==2 and len(go[i][H*2-0])==2):
                                #if ((H%2==1 and len(go[i][H*2-2])>2) or (H%2==0 and len(go[i][H*2-0])>2)):
                                go_end.append(deepcopy(go[i])) # записываем удаляемый ход (без полуходов, где не ели)
                                if (1):
                                    del go_end[len(go_end)-1][len(go_end[len(go_end)-1])-1]
                                    del go_end[len(go_end)-1][len(go_end[len(go_end)-1])-1]
                                    del go_end[len(go_end)-1][len(go_end[len(go_end)-1])-1]
                                    del go_end[len(go_end)-1][len(go_end[len(go_end)-1])-1]
                                if (go_end[len(go_end)-1]==go_end[len(go_end)-2] or len(go_end[len(go_end)-1])==2):
                                    del go_end[len(go_end)-1]
                                
                                del go[i]
                            else:
                                i += 1
                        else:
                            i += 1
                    if (len(go)==1): # если удалили все
                        H += 666
                        i = 12345698765423456789 ###############
                        while (i<len(go_operation_save) and len(go_operation_save)>1): # записываем возможные ходы в данный момент времени, и каждый раз вызываем рекрусивно просчет helper
                            area_monitor1 = going(area_monitor, go_operation_save[i])
                            go.append([go_operation_save[i],evklid_lite(go, go_operation, area_monitor1)])
                            i = i + 1
                if (millis()-timer>=time_for_mozg+5000):
                    H -= 1
                    go = deepcopy(go_save)
                else:
                    H += 1
                if (H<=666 and 0):
                    canvas.create_rectangle(ras*11.2,ras*6.7,ras*11.8,ras*7.3,fill="white",outline="white")
                    canvas.create_text(ras*11.5,ras*7,text=H,font="Verdana 10",justify=CENTER,fill="red")
                    out_window.update()
                print(H, (millis()-timer)/1000, len(go)-1)
            timer1 = millis()

            if (H>=666 and 1): # комбинация
                #print("КОМБИНАЦИЯ")
                go.clear()
                go = deepcopy(go_end)
            elif (1):
                i = 1
                while (len(go_end)>i):
                    go.append(deepcopy(go_end[i]))
                    i += 1
            #if (not len(go_operation_save)==1): # не один вариант хода
            go_end.clear()
            go_save.clear()
            i = 1
            while (len(go)>i):
                if (len(go[i])<2):
                    del go[i]
                else:
                    i += 1
                    
            # теперь у нас есть массив go в котором хранятся все "интересные" нам варианты развития событий
            
            if (1):
                print("--------")
                if (1):
                    print("go[0]: ",end='')
                    print_mas(go)
                if (0):
                    print("*")
                    print("go_end[0]: ",end='')
                    print_mas(go_end)
                print ("count:",len(go)-1)
                print ("time:",(timer1-timer)/1000)
                print ("H:",H)
                print("---------------------")
            
            if(len(go)>=2 and 1): # gauss
                # проверяем на целесообразность
                flag = 0
                i = 1
                while (len(go)>i and flag==0):
                    if (go[i][len(go[i])-1]>=go[0]):
                        flag = 1
                    i += 1
                if (flag==1):
                    # берем один наш ход, смотрим, как на это может ответить соперник, если все хорошо, то "допускаем" и так в цикле по всему ходу
                    u = 1
                    while (len(go)>u):
                        i = 1
                        mas = []
                        mas.append(deepcopy(go[u]))
                        mas[0].append(u)
                        #mas = deepcopy(go)
                        while (len(go)>i):
                            if (go[u][0]==go[i][0] and i!=u):
                                mas.append(deepcopy(go[i]))
                                mas[len(mas)-1].append(i)
                            i += 1
                        if (gauss(go, deepcopy(mas))!=1): # если удалили строку в go
                            #pass
                            u += 1
                        #print("@")
                        #print_mas(mas)
                        #print("@")
                else:
                    i = go[0]
                    go.clear()
                    go.append(i)
                if (1):
                    if (len(go)>=2 and 1): # gauss old        <====================================================================================================
                        print("gauss()")
                        #go_save = deepcopy(go)
                        i = 1
                        # удаляем "хвосты" ходов, где никто не ест за ход
                        while (i<len(go)):
                            #print(i)
                            if (len(go[i][len(go[i])-2])==2):
                                del go[i][len(go[i])-1]
                                del go[i][len(go[i])-1]
                                if (go[i]==go[i-1]):
                                    del go[i]
                                else:
                                    i += 1
                            else:
                                i += 1
                        # выбираем ход, где мы съели не меньше, чем отдали
                        i = 1
                        while (i<len(go)):
                            u = 0
                            flag = 0
                            while (u<len(go[i])):
                                y = 0
                                uu = 1
                                while (uu+1<len(go[i][u])):
                                    if (go[i][u][uu]>10000):
                                        if (int(go[i][u][uu]/1000)%10==1): # дамка
                                            y += 500
                                        else:
                                            y += 200
                                    uu += 2
                                #flag += int(len(go[i][u])/2) 
                                if (u%4==0): # мой ход
                                    flag += y
                                else: # ход соперника
                                    flag -= y
                                u += 2
                            if (flag<0 and go[i][len(go[i])-1]<go[0]): #   -100
                                del go[i]
                            else:
                                i += 1
                        # выбираем ходы, которые наиолее вероятно совершит противник
                        if (0):
                            # удаляем такие-же ходы (go) из go_save
                            i = 1
                            while (i<len(go)):
                                u = 1
                                while (u<len(go_save)):
                                    if (go[i]==go_save[u]):
                                        del go_save[u]
                                    else:
                                        u += 1
                                i += 1
                            # проверяем, были ли удалены те ходы или нет
                            i = 1
                            while (i<len(go)):
                                u = 1
                                while (u<len(go_save)):
                                    if (go[i][0]==go_save[u][0] and go[i][2]!=go_save[u][2]):
                                        del go[i]
                                        u = 34567898765434567890987654
                                        i -= 1
                                    else:
                                        u += 1
                                i += 1
                if (1):
                    print("--------")
                    if (1):
                        print("go[0]: ",end='')
                        print_mas(go)
                    print ("count:",len(go)-1)
                    print ("time:",(timer1-timer)/1000)
                    print ("H:",H)
                    print("---------------------")
                if (len(go)<=1):
                    print("(1) nostardamus_first_mod")
                    go_operation = nostardamus_first_mod(area_monitor, go_color)
                    print("===>",go_operation)
                else:
                    print("nostardamus!")
                    go_operation = go[randint(1, len(go)-1)][0]
                    print("===>",go_operation)
            elif(1):
                print("(2) nostardamus_first_mod")
                go_operation = nostardamus_first_mod(area_monitor, go_color)
                print("===>",go_operation)
                    #go_operation = deepcopy(go[i][0])
        return go_operation
                    
    #print("level_hard:",level_hard)
    if (level_hard==1):
        go_operation = generator_move(area_monitor,go_color)
        l = randint(0, len(go_operation)-1)
        go_operation = deepcopy(go_operation[l])
        return go_operation
    elif (level_hard==2):
        return nostardamus_first_mod(area_monitor, go_color)
    elif (level_hard==3):
        return nostardamus_ultra(area_monitor, go_color)
    else:
        return -1

def test():
    level_hard = 3
    print("level_hard:",level_hard)
    print("===> test 1:")
    area_monitor = [[9, 2, 9, 2, 9, 2, 9, 2],
                    [2, 9, 2, 9, 2, 9, 2, 9],
                    [9, 2, 9, 2, 9, 2, 9, 2],
                    [0, 9, 0, 9, 0, 9, 0, 9],
                    [9, 0, 9, 0, 9, 0, 9, 0],
                    [1, 9, 1, 9, 1, 9, 1, 9],
                    [9, 1, 9, 1, 9, 1, 9, 1],    
                    [1, 9, 1, 9, 1, 9, 1, 9]]    
    print(BARS_mind(area_monitor, 1, level_hard))
    print("===> test 2:")
    area_monitor = [[9, 2, 9, 2, 9, 2, 9, 2],
                    [2, 9, 2, 9, 2, 9, 2, 9],
                    [9, 2, 9, 2, 9, 2, 9, 2],
                    [0, 9, 0, 9, 0, 9, 0, 9],
                    [9, 0, 9, 2, 9, 0, 9, 0],
                    [1, 9, 1, 9, 1, 9, 1, 9],
                    [9, 1, 9, 1, 9, 1, 9, 1],    
                    [1, 9, 1, 9, 1, 9, 1, 9]]
    print(BARS_mind(area_monitor, 1, level_hard))
    print("===> successful test")

def test2():
    level_hard = 3
    print("level_hard:",level_hard)
    #print("===> test 1:")
    area_monitor = [[9, 0, 9, 0, 9, 2, 9, 0],
                    [0, 9, 0, 9, 2, 9, 0, 9],
                    [9, 2, 9, 2, 9, 0, 9, 0],
                    [0, 9, 0, 9, 0, 9, 0, 9],
                    [9, 0, 9, 1, 9, 0, 9, 0],
                    [1, 9, 1, 9, 0, 9, 0, 9],
                    [9, 1, 9, 0, 9, 0, 9, 0],
                    [0, 9, 0, 9, 0, 9, 0, 9]]   
    print(BARS_mind(area_monitor, 1, level_hard))
    print("===> successful test")

def test3():
    level_hard = 3
    print("level_hard:",level_hard)
    #print("===> test 1:")
    area_monitor = [[9, 0, 9, 0, 9, 0, 9, 11],
                    [0, 9, 0, 9, 0, 9, 0, 9],
                    [9, 0, 9, 2, 9, 0, 9, 0],
                    [0, 9, 0, 9, 0, 9, 0, 9],
                    [9, 0, 9, 0, 9, 0, 9, 12],
                    [0, 9, 0, 9, 2, 9, 0, 9],
                    [9, 0, 9, 0, 9, 0, 9, 0],
                    [0, 9, 0, 9, 0, 9, 0, 9]]   
    print(BARS_mind(area_monitor, 2, level_hard))
    print("===> successful test")

def test4(): # game over
    level_hard = 3
    print("level_hard:",level_hard)
    #print("===> test 1:")
    area_monitor = [[9, 2, 9, 2, 9, 2, 9, 2],
                    [0, 9, 0, 9, 0, 9, 0, 9],
                    [9, 0, 9, 0, 9, 0, 9, 0],
                    [0, 9, 0, 9, 0, 9, 0, 9],
                    [9, 0, 9, 0, 9, 0, 9, 0],
                    [0, 9, 0, 9, 0, 9, 0, 9],
                    [9, 0, 9, 0, 9, 0, 9, 0],
                    [0, 9, 0, 9, 0, 9, 0, 9]]   
    print(BARS_mind(area_monitor, 2, level_hard))
    print("===> successful test")

def test5():
    level_hard = 3
    print("level_hard:",level_hard)
    #print("===> test 1:")
    area_monitor = [[9, 2, 9, 2, 9, 2, 9, 2],
                    [0, 9, 0, 9, 0, 9, 0, 9],
                    [9, 0, 9, 0, 9, 0, 9, 0],
                    [0, 9, 0, 9, 0, 9, 0, 9],
                    [9, 0, 9, 0, 9, 0, 9, 0],
                    [0, 9, 0, 9, 2, 9, 0, 9],
                    [9, 0, 9, 0, 9, 0, 9, 0],
                    [1, 9, 1, 9, 1, 9, 1, 9]]   
    print(BARS_mind(area_monitor, 2, level_hard))
    print("===> successful test")

def test6():
    level_hard = 3
    print("level_hard:",level_hard)
    #print("===> test 1:")
    area_monitor = [[9, 2, 9, 2, 9, 0, 9, 2],
                    [2, 9, 0, 9, 0, 9, 0, 9],
                    [9, 0, 9, 11, 9, 2, 9, 0],
                    [2, 9, 0, 9, 0, 9, 0, 9],
                    [9, 1, 9, 1, 9, 1, 9, 0],
                    [1, 9, 1, 9, 0, 9, 0, 9],
                    [9, 0, 9, 0, 9, 0, 9, 0],
                    [1, 9, 1, 9, 1, 9, 1, 9]]   
    print(BARS_mind(area_monitor, 2, level_hard))
    print("===> successful test")

def test7():
    level_hard = 3
    print("level_hard:",level_hard)
    #print("===> test 1:")
    area_monitor = [[9, 2, 9, 0, 9, 2, 9, 2],
                    [0, 9, 0, 9, 0, 9, 0, 9],
                    [9, 0, 9, 0, 9, 0, 9, 0],
                    [0, 9, 2, 9, 2, 9, 0, 9],
                    [9, 1, 9, 2, 9, 0, 9, 0],
                    [1, 9, 0, 9, 2, 9, 1, 9],
                    [9, 1, 9, 0, 9, 0, 9, 0],
                    [1, 9, 1, 9, 0, 9, 1, 9]]   
    print(BARS_mind(area_monitor, 2, level_hard))
    print("===> successful test")

def test8():
    level_hard = 3
    print("level_hard:",level_hard)
    #print("===> test 1:")
    area_monitor = [[9, 2, 9, 2, 9, 2, 9, 2],
                    [0, 9, 0, 9, 0, 9, 0, 9],
                    [9, 0, 9, 1, 9, 0, 9, 0],
                    [2, 9, 0, 9, 0, 9, 0, 9],
                    [9, 0, 9, 0, 9, 0, 9, 2],
                    [1, 9, 0, 9, 1, 9, 0, 9],
                    [9, 1, 9, 0, 9, 0, 9, 0],
                    [1, 9, 0, 9, 1, 9, 0, 9]]   
    print(BARS_mind(area_monitor, 2, level_hard))
    print("===> successful test")

test2() 

'''
    area_monitor = [[9, 0, 9, 0, 9, 0, 9, 0],
                    [0, 9, 0, 9, 0, 9, 0, 9],
                    [9, 0, 9, 0, 9, 0, 9, 0],
                    [0, 9, 0, 9, 0, 9, 0, 9],
                    [9, 0, 9, 0, 9, 0, 9, 0],
                    [0, 9, 0, 9, 0, 9, 0, 9],
                    [9, 0, 9, 0, 9, 0, 9, 0],
                    [0, 9, 0, 9, 0, 9, 0, 9]]

'''
